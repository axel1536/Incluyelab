package com.incluyelab.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PerfilPostulante implements Serializable {
    private int idUsuario;
    private String nombre="", correo="", telefono="", titular="", ubicacion="", acercaDe="";
    private String habilidades="", adaptacionRequerida="", fotoUrl="", cvNombre="", cvArchivo="";
    private final List<Experiencia> experiencias=new ArrayList<>();
    private final List<Educacion> educacion=new ArrayList<>();
    private final List<Certificacion> certificaciones=new ArrayList<>();
    public int getIdUsuario(){return idUsuario;} public void setIdUsuario(int v){idUsuario=v;}
    public String getNombre(){return nombre;} public void setNombre(String v){nombre=s(v);}
    public String getCorreo(){return correo;} public void setCorreo(String v){correo=s(v);}
    public String getTelefono(){return telefono;} public void setTelefono(String v){telefono=s(v);}
    public String getTitular(){return titular;} public void setTitular(String v){titular=s(v);}
    public String getUbicacion(){return ubicacion;} public void setUbicacion(String v){ubicacion=s(v);}
    public String getAcercaDe(){return acercaDe;} public void setAcercaDe(String v){acercaDe=s(v);}
    public String getHabilidades(){return habilidades;} public void setHabilidades(String v){habilidades=s(v);}
    public String getAdaptacionRequerida(){return adaptacionRequerida;} public void setAdaptacionRequerida(String v){adaptacionRequerida=s(v);}
    public String getFotoUrl(){return fotoUrl;} public void setFotoUrl(String v){fotoUrl=s(v);}
    public String getCvNombre(){return cvNombre;} public void setCvNombre(String v){cvNombre=s(v);}
    public String getCvArchivo(){return cvArchivo;} public void setCvArchivo(String v){cvArchivo=s(v);}
    public List<Experiencia> getExperiencias(){return experiencias;}
    public List<Educacion> getEducacion(){return educacion;}
    public List<Certificacion> getCertificaciones(){return certificaciones;}
    private String s(String v){return v==null?"":v;}
    public static class Experiencia implements Serializable { public int id; public String cargo="",organizacion="",inicio="",fin="",descripcion=""; }
    public static class Educacion implements Serializable { public int id; public String institucion="",carrera="",inicio="",fin="",descripcion=""; }
    public static class Certificacion implements Serializable { public int id; public String nombre="",emisor="",fecha="",url=""; }
}
