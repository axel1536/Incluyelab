package com.incluyelab.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class Oferta implements Serializable {
    private int idOferta;
    private int idEmpresa;
    private String empresa;
    private String logoUrl;
    private String titulo;
    private String modalidad;
    private String ubicacion;
    private String adaptaciones;
    private String apoyos = "";

    public String getApoyos() { return apoyos; }
    public void setApoyos(String apoyos) { this.apoyos = apoyos == null ? "" : apoyos; }
    public String getCategoriasApoyo() { return ApoyosOferta.categorias(apoyos); }
    public String getEtiquetasApoyo() { return ApoyosOferta.etiquetas(apoyos); }
    private String descripcion;
    private BigDecimal salario;
    private String estado;

    public int getIdOferta() {
        return idOferta;
    }

    public void setIdOferta(int idOferta) {
        this.idOferta = idOferta;
    }

    public int getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(int idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getLogoUrl() {
        return logoUrl;
    }

    public void setLogoUrl(String logoUrl) {
        this.logoUrl = logoUrl;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getModalidad() {
        return modalidad;
    }

    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getAdaptaciones() {
        return adaptaciones;
    }

    public void setAdaptaciones(String adaptaciones) {
        this.adaptaciones = adaptaciones;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
