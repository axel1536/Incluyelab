package com.incluyelab.model;

/** Reference brands, not a statement of recruitment partnerships or job availability. */
public final class DirectorioEmpresas {
    private DirectorioEmpresas() { }
    // Name, local logo, sector, directory scope, official website.
    public static String[][] listar() {
        return new String[][] {
            {"BCP","bcp.svg","Banca","Peru","https://www.viabcp.com/"},
            {"Interbank","interbank.svg","Banca","Peru","https://interbank.pe/"},
            {"Alicorp","alicorp.png","Consumo masivo","Peru","https://www.alicorp.com.pe/"},
            {"R\u00edmac","rimac.png","Seguros","Peru","https://www.rimac.com/"},
            {"Entel Per\u00fa","entel.webp","Telecomunicaciones","Peru","https://www.entel.pe/"},
            {"Sodimac Per\u00fa","sodimac.png","Retail","Peru","https://www.sodimac.com.pe/"},
            {"Inkafarma","inkafarma.png","Salud","Peru","https://inkafarma.pe/"},
            {"Yape","yape.png","Tecnologia","Peru","https://www.yape.com.pe/"},
            {"Claro","claro.png","Telecomunicaciones","Peru","https://www.claro.com.pe/"},
            {"Movistar","movistar.svg","Telecomunicaciones","Peru","https://www.movistar.com.pe/"},
            {"Tottus","tottus.png","Supermercados","Peru","https://www.tottus.com.pe/"},
            {"UPN","upn.svg","Educacion","Peru","https://www.upn.edu.pe/"},
            {"UTP","utp.svg","Educacion","Peru","https://www.utp.edu.pe/"},
            {"Mercado Libre","mercadolibre.png","Comercio electronico","Peru","https://www.mercadolibre.com.pe/"},
            {"Falabella","falabella.png","Retail","Peru","https://www.falabella.com.pe/"},
            {"Cl\u00ednica Internacional","internacional.png","Salud","Peru","https://www.clinicainternacional.com.pe/"},
            {"Cl\u00ednica San Pablo Surco","sanpablo.png","Salud","Peru","https://www.sanpablo.com.pe/"},
            {"Pardos Chicken","pardos.png","Restaurantes","Peru","https://www.pardoschicken.pe/"},
            {"Microsoft","microsoft.png","Tecnologia","Internacional","https://www.microsoft.com/"},
            {"Amazon","amazon.png","Comercio y tecnologia","Internacional","https://www.aboutamazon.com/"},
            {"Walmart","walmart.svg","Retail","Internacional","https://corporate.walmart.com/"},
            {"SAP","sap.svg","Software empresarial","Internacional","https://www.sap.com/"},
            {"ACCIONA","acciona.jpg","Infraestructura y energia","Internacional","https://www.acciona.com/es/"}
        };
    }
}
