package com.incluyelab.dao;

import com.incluyelab.config.Conexion;
import com.incluyelab.model.Oferta;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OfertaDAO {
    public List<Oferta> listarActivas() throws SQLException {
        return listarPorSql("WHERE o.estado='activa' AND e.estado_revision='aprobada' AND EXISTS (SELECT 1 FROM usuarios u WHERE u.id_usuario=e.id_usuario AND u.estado='activo' AND u.rol='EMPRESA')", 0);
    }

    public List<Oferta> listarPorEmpresa(int idEmpresa) throws SQLException {
        return listarPorSql("WHERE o.id_empresa=?", idEmpresa);
    }

    public List<Oferta> listarTodas() throws SQLException {
        return listarPorSql("", 0);
    }

    public void registrar(Oferta oferta) throws SQLException {
        String sql = "INSERT INTO ofertas(id_empresa, titulo, modalidad, ubicacion, adaptaciones, descripcion, salario, apoyos, estado) SELECT ?,?,?,?,?,?,?,?, 'activa' FROM empresas e JOIN usuarios u ON u.id_usuario=e.id_usuario WHERE e.id_empresa=? AND e.estado_revision='aprobada' AND u.estado='activo' AND u.rol='EMPRESA'";
        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, oferta.getIdEmpresa());
            ps.setString(2, oferta.getTitulo());
            ps.setString(3, oferta.getModalidad());
            ps.setString(4, oferta.getUbicacion());
            ps.setString(5, oferta.getAdaptaciones());
            ps.setString(6, oferta.getDescripcion());
            ps.setBigDecimal(7, oferta.getSalario() == null ? BigDecimal.ZERO : oferta.getSalario());
            ps.setString(8, oferta.getApoyos());
            ps.setInt(9, oferta.getIdEmpresa());
            if(ps.executeUpdate()!=1) throw new IllegalArgumentException("Tu empresa requiere aprobacion antes de publicar.");
        }
    }

    private List<Oferta> listarPorSql(String where, int idEmpresa) throws SQLException {
        List<Oferta> ofertas = new ArrayList<>();
        String sql = "SELECT o.id_oferta, o.id_empresa, e.razon_social empresa, e.logo_url, o.titulo, o.modalidad, o.ubicacion, "
                + "o.adaptaciones, o.apoyos, o.descripcion, o.salario, o.estado "
                + "FROM ofertas o INNER JOIN empresas e ON o.id_empresa=e.id_empresa " + where
                + " ORDER BY o.id_oferta DESC";
        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            if (where.contains("?")) {
                ps.setInt(1, idEmpresa);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Oferta o = new Oferta();
                    o.setIdOferta(rs.getInt("id_oferta"));
                    o.setIdEmpresa(rs.getInt("id_empresa"));
                    o.setEmpresa(rs.getString("empresa"));
                    o.setLogoUrl(rs.getString("logo_url"));
                    o.setTitulo(rs.getString("titulo"));
                    o.setModalidad(rs.getString("modalidad"));
                    o.setUbicacion(rs.getString("ubicacion"));
                    o.setAdaptaciones(rs.getString("adaptaciones"));
                    o.setApoyos(rs.getString("apoyos"));
                    o.setDescripcion(rs.getString("descripcion"));
                    o.setSalario(rs.getBigDecimal("salario"));
                    o.setEstado(rs.getString("estado"));
                    ofertas.add(o);
                }
            }
        }
        return ofertas;
    }
}
