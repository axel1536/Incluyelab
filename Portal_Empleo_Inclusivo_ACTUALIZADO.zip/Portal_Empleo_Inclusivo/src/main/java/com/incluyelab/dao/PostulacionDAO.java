package com.incluyelab.dao;

import com.incluyelab.config.Conexion;
import com.incluyelab.model.Postulacion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PostulacionDAO {
    public void registrar(int idUsuario, int idOferta) throws SQLException {
        String sql = "INSERT INTO postulaciones(id_usuario, id_oferta, estado) "
                + "SELECT ?, o.id_oferta, 'pendiente' FROM ofertas o JOIN empresas e ON e.id_empresa=o.id_empresa JOIN usuarios u ON u.id_usuario=e.id_usuario WHERE o.id_oferta=? AND o.estado='activa' AND e.estado_revision='aprobada' AND u.estado='activo' AND u.rol='EMPRESA' "
                + "AND NOT EXISTS (SELECT 1 FROM postulaciones p WHERE p.id_usuario=? AND p.id_oferta=o.id_oferta)";
        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            ps.setInt(2, idOferta);
            ps.setInt(3, idUsuario);
            if (ps.executeUpdate() == 0) {
                throw new SQLException("Ya postulaste a esta oferta o la oferta no esta disponible.");
            }
        }
    }

    public List<Postulacion> listarPorUsuario(int idUsuario) throws SQLException {
        return listar("WHERE p.id_usuario=?", idUsuario);
    }

    public List<Postulacion> listarTodas() throws SQLException {
        return listar("", 0);
    }

    public List<Postulacion> listarPorEmpresa(int idUsuarioEmpresa) throws SQLException {
        return listar("WHERE e.id_usuario=?", idUsuarioEmpresa);
    }

    public Postulacion obtenerParaEmpresa(int idPostulacion,int idUsuarioEmpresa) throws SQLException {
        List<Postulacion> lista=listar("WHERE p.id_postulacion=? AND e.id_usuario="+idUsuarioEmpresa,idPostulacion);
        return lista.isEmpty()?null:lista.get(0);
    }

    public void cambiarEstadoEmpresa(int idPostulacion,int idUsuarioEmpresa,String estado) throws SQLException {
        if(!java.util.Arrays.asList("en revision","aceptado","rechazado").contains(estado))throw new IllegalArgumentException("Estado no valido.");
        String sql="UPDATE postulaciones p JOIN ofertas o ON o.id_oferta=p.id_oferta JOIN empresas e ON e.id_empresa=o.id_empresa SET p.estado=? WHERE p.id_postulacion=? AND e.id_usuario=?";
        try(Connection cn=Conexion.getConnection();PreparedStatement ps=cn.prepareStatement(sql)){ps.setString(1,estado);ps.setInt(2,idPostulacion);ps.setInt(3,idUsuarioEmpresa);if(ps.executeUpdate()!=1)throw new IllegalArgumentException("Postulacion no disponible.");}
    }

    private List<Postulacion> listar(String where, int idUsuario) throws SQLException {
        List<Postulacion> lista = new ArrayList<>();
        String sql = "SELECT p.id_postulacion, p.id_usuario, p.id_oferta, u.nombre postulante,u.correo, o.titulo oferta, "
                + "e.razon_social empresa, p.estado, DATE_FORMAT(p.fecha_postulacion, '%d/%m/%Y %H:%i') fecha_postulacion,"
                + "COALESCE(pp.titular,'') titular,COALESCE(pp.ubicacion,'') ubicacion,COALESCE(pp.habilidades,'') habilidades,COALESCE(pp.cv_nombre,'') cv_nombre "
                + "FROM postulaciones p INNER JOIN usuarios u ON p.id_usuario=u.id_usuario "
                + "INNER JOIN ofertas o ON p.id_oferta=o.id_oferta "
                + "INNER JOIN empresas e ON o.id_empresa=e.id_empresa LEFT JOIN perfiles_postulantes pp ON pp.id_usuario=u.id_usuario " + where
                + " ORDER BY p.id_postulacion DESC";
        try (Connection cn = Conexion.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            if (where.contains("?")) {
                ps.setInt(1, idUsuario);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Postulacion p = new Postulacion();
                    p.setIdPostulacion(rs.getInt("id_postulacion"));
                    p.setIdUsuario(rs.getInt("id_usuario"));
                    p.setIdOferta(rs.getInt("id_oferta"));
                    p.setPostulante(rs.getString("postulante"));
                    p.setOferta(rs.getString("oferta"));
                    p.setEmpresa(rs.getString("empresa"));
                    p.setEstado(rs.getString("estado"));
                    p.setFechaPostulacion(rs.getString("fecha_postulacion"));
                    p.setCorreo(rs.getString("correo"));p.setTitular(rs.getString("titular"));p.setUbicacion(rs.getString("ubicacion"));p.setHabilidades(rs.getString("habilidades"));p.setCvNombre(rs.getString("cv_nombre"));
                    lista.add(p);
                }
            }
        }
        return lista;
    }
}
