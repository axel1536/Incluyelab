package com.incluyelab.servlet;

import com.incluyelab.dao.PostulacionDAO;
import com.incluyelab.model.Usuario;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "PostularServlet", urlPatterns = {"/postular"})
public class PostularServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Usuario usuario = (Usuario) request.getSession().getAttribute("usuario");
        if (usuario == null || !"POSTULANTE".equals(usuario.getRol())) {
            response.sendRedirect("login");
            return;
        }
        try {
            int idOferta = Integer.parseInt(request.getParameter("idOferta"));
            new PostulacionDAO().registrar(usuario.getIdUsuario(), idOferta);
            response.sendRedirect("postulante?ok=postulacion");
        } catch (Exception ex) {
            log("No se pudo registrar la postulacion", ex);
            request.getSession().setAttribute("flashError", "No se pudo registrar. Verifica si ya postulaste o si la oferta sigue disponible.");
            response.sendRedirect("postulante");
        }
    }
}
