package com.incluyelab.servlet;

import com.incluyelab.dao.EmpresaDAO;
import com.incluyelab.dao.OfertaDAO;
import com.incluyelab.dao.PostulacionDAO;
import com.incluyelab.model.Empresa;
import com.incluyelab.model.Usuario;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "EmpresaServlet", urlPatterns = {"/empresa"})
public class EmpresaServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Usuario usuario = (Usuario) request.getSession().getAttribute("usuario");
        if (usuario == null || !"EMPRESA".equals(usuario.getRol())) {
            response.sendRedirect("login");
            return;
        }
        try {
            if(request.getSession().getAttribute("empresaCsrf")==null) request.getSession().setAttribute("empresaCsrf",java.util.UUID.randomUUID().toString());
            Empresa empresa = new EmpresaDAO().obtenerPorUsuario(usuario.getIdUsuario());
            request.setAttribute("empresa", empresa);
            request.setAttribute("ofertas", empresa == null ? null : new OfertaDAO().listarPorEmpresa(empresa.getIdEmpresa()));
            request.setAttribute("candidatos", empresa == null ? null : new PostulacionDAO().listarPorEmpresa(usuario.getIdUsuario()));
        } catch (Exception ex) {
            log("No se pudo cargar la empresa",ex);
            request.setAttribute("error", "No se pudo cargar el panel. Intenta nuevamente.");
        }
        request.getRequestDispatcher("/empresa.jsp").forward(request, response);
    }
}
