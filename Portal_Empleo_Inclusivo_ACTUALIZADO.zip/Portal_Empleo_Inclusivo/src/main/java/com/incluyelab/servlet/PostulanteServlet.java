package com.incluyelab.servlet;

import com.incluyelab.dao.OfertaDAO;
import com.incluyelab.dao.PostulacionDAO;
import com.incluyelab.model.Usuario;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "PostulanteServlet", urlPatterns = {"/postulante"})
public class PostulanteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Usuario usuario = (Usuario) request.getSession().getAttribute("usuario");
        if (usuario == null || !"POSTULANTE".equals(usuario.getRol())) {
            response.sendRedirect("login");
            return;
        }
        try {
            request.setAttribute("ofertas", new OfertaDAO().listarActivas());
            request.setAttribute("postulaciones", new PostulacionDAO().listarPorUsuario(usuario.getIdUsuario()));
        } catch (Exception ex) {
            request.setAttribute("error", ex.getMessage());
        }
        request.getRequestDispatcher("/postulante.jsp").forward(request, response);
    }
}
