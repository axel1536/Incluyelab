package com.incluyelab.servlet;

import com.incluyelab.dao.UsuarioDAO;
import com.incluyelab.model.Usuario;
import com.incluyelab.security.Passwords;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "RegistroServlet", urlPatterns = {"/registro"})
public class RegistroServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/registro.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String rol = request.getParameter("rol");
        String nombre = request.getParameter("nombre");
        String correo = request.getParameter("correo");
        String clave = request.getParameter("contrasena");
        if ((!"POSTULANTE".equals(rol) && !"EMPRESA".equals(rol)) || nombre == null || nombre.trim().isEmpty()
                || nombre.length() > 120 || correo == null || !correo.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+")
                || correo.length() > 150 || Passwords.policyError(clave) != null) {
            request.setAttribute("error", Passwords.policyError(clave)!=null?Passwords.policyError(clave):"Revisa los campos e ingresa un correo válido.");
            request.getRequestDispatcher("/registro.jsp").forward(request, response);
            return;
        }
        Usuario usuario = new Usuario();
        usuario.setNombre(request.getParameter("nombre"));
        usuario.setCorreo(request.getParameter("correo"));
        usuario.setContrasena(request.getParameter("contrasena"));
        usuario.setRol(request.getParameter("rol"));
        try {
            new UsuarioDAO().registrar(usuario);
            String oferta = request.getParameter("oferta");
            response.sendRedirect("login?registro=ok" + (oferta != null && oferta.matches("[0-9]{1,9}") ? "&oferta=" + oferta : ""));
        } catch (Exception ex) {
            log("No se pudo registrar la cuenta", ex);
            request.setAttribute("error", ex instanceof java.sql.SQLIntegrityConstraintViolationException
                    ? "Ese correo ya tiene una cuenta. Ingresa o utiliza otro correo."
                    : "No se pudo crear la cuenta. Intenta nuevamente en unos minutos.");
            request.getRequestDispatcher("/registro.jsp").forward(request, response);
        }
    }
}
