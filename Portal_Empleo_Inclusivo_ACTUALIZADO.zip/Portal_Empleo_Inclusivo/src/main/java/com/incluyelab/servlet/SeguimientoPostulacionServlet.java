package com.incluyelab.servlet;

import com.incluyelab.dao.PostulacionDAO;
import com.incluyelab.model.Usuario;
import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/empresa/postulacion")
public class SeguimientoPostulacionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException{
        Usuario u=(Usuario)req.getSession().getAttribute("usuario");Object token=req.getSession().getAttribute("empresaCsrf");
        if(u==null||!"EMPRESA".equals(u.getRol())||token==null||!token.equals(req.getParameter("csrf"))){res.sendError(403);return;}
        try{new PostulacionDAO().cambiarEstadoEmpresa(Integer.parseInt(req.getParameter("id")),u.getIdUsuario(),req.getParameter("estado"));req.getSession().setAttribute("empresaNotice","Estado de la postulacion actualizado.");res.sendRedirect(req.getContextPath()+"/empresa#candidatos");}
        catch(IllegalArgumentException|java.sql.SQLException ex){log("No se pudo actualizar la postulacion",ex);req.getSession().setAttribute("empresaError",ex instanceof IllegalArgumentException?ex.getMessage():"No se pudo guardar el cambio.");res.sendRedirect(req.getContextPath()+"/empresa#candidatos");}
    }
}
