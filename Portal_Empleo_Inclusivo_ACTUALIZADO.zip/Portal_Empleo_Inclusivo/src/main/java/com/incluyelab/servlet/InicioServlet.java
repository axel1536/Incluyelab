package com.incluyelab.servlet;

import com.incluyelab.dao.OfertaDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "InicioServlet", urlPatterns = {"/inicio"})
public class InicioServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            request.setAttribute("ofertas", new OfertaDAO().listarActivas());
            request.setAttribute("empresasPublicas",new com.incluyelab.dao.EmpresaDAO().listarPublicas());
        } catch (Exception ex) {
            request.setAttribute("error", "No se pudo cargar la lista de ofertas: " + ex.getMessage());
        }
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
}
