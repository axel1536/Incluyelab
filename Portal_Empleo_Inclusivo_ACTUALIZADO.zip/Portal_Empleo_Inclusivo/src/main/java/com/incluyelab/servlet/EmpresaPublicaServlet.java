package com.incluyelab.servlet;

import com.incluyelab.dao.EmpresaDAO;
import com.incluyelab.model.*;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/empresa-publica")
public class EmpresaPublicaServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {
        try{
            EmpresaDAO dao=new EmpresaDAO();Empresa e=null;
            if(req.getParameter("id")!=null){
                int id=Integer.parseInt(req.getParameter("id"));
                if(dao.esPublica(id))e=dao.obtener(id);
            }else{
                for(String[] marca:DirectorioEmpresas.listar()){
                    if(marca[0].equals(req.getParameter("marca"))){
                        e=new Empresa();e.setRazonSocial(marca[0]);e.setSector(marca[2]);
                        req.setAttribute("sitioOficial",marca[4]);
                        for(Empresa registrada:dao.listarPublicas()){
                            String a=normalizar(registrada.getRazonSocial()),b=normalizar(marca[0]);
                            if(a.equals(b) || (b.equals("rimac") && a.equals("rimac seguros"))){e=registrada;break;}
                        }
                        break;
                    }
                }
            }
            if(e==null){res.sendError(404,"Empresa no disponible.");return;}
            req.setAttribute("ficha",e);
            req.getRequestDispatcher("/WEB-INF/empresa-publica.jsp").forward(req,res);
        }catch(NumberFormatException ex){res.sendError(404);}
        catch(java.sql.SQLException ex){log("Error al consultar empresa",ex);res.sendError(503);}
    }
    private String normalizar(String s){return java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(java.util.Locale.ROOT);}
}
