package com.incluyelab.servlet;

import com.incluyelab.dao.*;
import com.incluyelab.model.*;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/empresa/candidato")
public class CandidatoServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        Usuario u=(Usuario)req.getSession().getAttribute("usuario");
        try{int id=Integer.parseInt(req.getParameter("id"));Postulacion p=new PostulacionDAO().obtenerParaEmpresa(id,u.getIdUsuario());if(p==null){res.sendError(404);return;}req.setAttribute("postulacion",p);req.setAttribute("perfilProfesional",new PerfilPostulanteDAO().obtener(p.getIdUsuario()));req.getRequestDispatcher("/WEB-INF/candidato.jsp").forward(req,res);}
        catch(NumberFormatException ex){res.sendError(404);}catch(java.sql.SQLException ex){log("No se pudo abrir candidato",ex);res.sendError(503);}
    }
}
