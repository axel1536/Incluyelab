package com.incluyelab.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private static final String DEFAULT_URL = "jdbc:mysql://localhost:3306/portal_empleo_inclusivo?useSSL=false&serverTimezone=America/Lima&allowPublicKeyRetrieval=true";
    private static final String DEFAULT_USER = "incluyelab_app";
    private static final String DEFAULT_PASSWORD = "123456";

    private Conexion() {
    }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            throw new SQLException("No se encontro el driver de MySQL.", ex);
        }

        String url = valueOrDefault(System.getenv("DB_URL"), DEFAULT_URL);
        String user = valueOrDefault(System.getenv("DB_USER"), DEFAULT_USER);
        String password = valueOrDefault(System.getenv("DB_PASSWORD"), DEFAULT_PASSWORD);
        return DriverManager.getConnection(url, user, password);
    }

    private static String valueOrDefault(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value;
    }
}
