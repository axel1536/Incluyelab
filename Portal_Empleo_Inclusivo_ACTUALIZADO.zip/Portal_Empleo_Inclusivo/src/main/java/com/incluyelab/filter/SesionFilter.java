package com.incluyelab.filter;

import com.incluyelab.dao.UsuarioDAO;
import com.incluyelab.model.Usuario;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;

@WebFilter(urlPatterns = "/*", dispatcherTypes = DispatcherType.REQUEST)
public class SesionFilter implements Filter {
    public static String panel(Usuario usuario) {
        switch (usuario.getRol()) {
            case "ADMIN": return "/admin";
            case "EMPRESA": return "/empresa";
            default: return "/postulante";
        }
    }

    @Override
    public void doFilter(ServletRequest input, ServletResponse output, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) input;
        HttpServletResponse res = (HttpServletResponse) output;
        req.setCharacterEncoding("UTF-8");
        String ruta = req.getServletPath();
        if (ruta.startsWith("/assets/")) { chain.doFilter(req,res); return; }
        res.setHeader("Cache-Control","no-store, no-cache, must-revalidate");
        res.setHeader("Pragma","no-cache");
        res.setDateHeader("Expires",0);
        HttpSession sesion = req.getSession(false);
        Usuario usuario = sesion == null ? null : (Usuario) sesion.getAttribute("usuario");
        boolean revocada = false;
        // Recheck the database so disabling an account also revokes an existing session.
        if (usuario != null) {
            try {
                Usuario actual = new UsuarioDAO().obtenerActivo(usuario.getIdUsuario());
                if (actual == null || !actual.getRol().equals(usuario.getRol())
                        || !java.util.Objects.equals(actual.getCredencialVersion(),usuario.getCredencialVersion())) {
                    sesion.invalidate(); sesion = null; usuario = null; revocada = true;
                } else { usuario = actual; sesion.setAttribute("usuario",actual); }
            } catch (SQLException ex) {
                req.getServletContext().log("No se pudo verificar la sesion",ex);
                res.sendError(503,"No se pudo verificar la sesion. Intenta nuevamente."); return;
            }
        }
        String rol = null;
        if (ruta.equals("/revision-empresa") || ruta.equals("/admin") || ruta.equals("/admin.jsp")) rol = "ADMIN";
        if (ruta.equals("/empresa/perfil") || ruta.equals("/empresa/candidato") || ruta.equals("/empresa/postulacion") || ruta.equals("/empresa") || ruta.equals("/empresa.jsp") || ruta.equals("/oferta")) rol = "EMPRESA";
        if (ruta.equals("/postulante") || ruta.equals("/postulante.jsp") || ruta.equals("/postular")) rol = "POSTULANTE";
        if ((rol != null || ruta.equals("/perfil") || ruta.equals("/perfil-profesional") || ruta.equals("/cv") || ruta.equals("/foto-perfil")) && usuario == null) {
            if (!"GET".equals(req.getMethod())) { res.sendError(403,"Inicia sesion para realizar esta accion."); return; }
            String motivo = revocada ? "revocada" : req.getRequestedSessionId()!=null && !req.isRequestedSessionIdValid() ? "expirada" : "requerida";
            res.sendRedirect(req.getContextPath()+"/login?sesion="+motivo); return;
        }
        if (rol != null && !rol.equals(usuario.getRol())) {
            if ("GET".equals(req.getMethod())) res.sendRedirect(req.getContextPath()+panel(usuario));
            else res.sendError(403,"Tu cuenta no tiene permiso para esta accion.");
            return;
        }
        if (ruta.equals("/login") || ruta.equals("/login.jsp") || ruta.equals("/registro") || ruta.equals("/registro.jsp")) {
            if (usuario != null) { res.sendRedirect(req.getContextPath()+panel(usuario)); return; }
        }
        if ("GET".equals(req.getMethod()) && ruta.endsWith(".jsp") && (rol != null || ruta.equals("/login.jsp") || ruta.equals("/registro.jsp"))) {
            res.sendRedirect(req.getContextPath()+ruta.substring(0,ruta.length()-4)); return;
        }
        chain.doFilter(req,res);
    }
}
