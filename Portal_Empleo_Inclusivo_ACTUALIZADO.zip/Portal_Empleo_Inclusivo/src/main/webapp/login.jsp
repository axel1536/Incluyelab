<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@include file="WEB-INF/jspf/helpers.jspf"%>
<!DOCTYPE html><html lang="es"><head><title>Ingresar | IncluyeLab</title><%@include file="WEB-INF/jspf/head.jspf"%></head><body>
<%@include file="WEB-INF/jspf/header.jspf"%>
<main class="container auth-layout" id="contenido">
    <section class="auth-intro"><p class="eyebrow teal">BIENVENIDO A INCLUYELAB</p><h1>El siguiente paso de tu carrera empieza contigo<span class="accent-dot">.</span></h1><p>Vuelve a tus oportunidades y sigue construyendo tu camino profesional.</p><ul class="auth-points"><li><i data-lucide="search" aria-hidden="true"></i> Ofertas con adaptaciones visibles</li><li><i data-lucide="heart-handshake" aria-hidden="true"></i> Oportunidades para todo tu talento</li><li><i data-lucide="clipboard-check" aria-hidden="true"></i> Tus postulaciones en un solo lugar</li></ul><p class="auth-note">Tu experiencia, tus habilidades y tus aspiraciones son lo que importa.</p></section>
    <section class="auth-form" aria-labelledby="login-title"><h2 id="login-title">Qué bueno verte de nuevo</h2><p class="muted">Ingresa con tu correo y contraseña.</p>
        <% if ("ok".equals(request.getParameter("registro"))) { %><div class="alert alert-success notice" role="status">Tu cuenta está lista. Ya puedes ingresar.</div><% } %>
        <% if ("actualizada".equals(request.getParameter("clave"))) { %><div class="alert alert-success notice" role="status">Contraseña actualizada. Ingresa con tu nueva contraseña.</div><% } %>
        <% if ("expirada".equals(request.getParameter("sesion"))) { %><div class="alert alert-warning" role="status">Tu sesión venció. Ingresa nuevamente para continuar.</div><% } %>
        <% if ("revocada".equals(request.getParameter("sesion"))) { %><div class="alert alert-warning" role="status">Tu acceso cambió. Inicia sesión nuevamente o consulta al administrador.</div><% } %>
        <% if ("requerida".equals(request.getParameter("sesion"))) { %><div class="alert alert-info" role="status">Inicia sesión para acceder a tu panel.</div><% } %>
        <% if (request.getAttribute("error") != null) { %><div class="alert alert-danger error" role="alert"><%=h(request.getAttribute("error"))%></div><% } %>
        <form method="post" action="<%=request.getContextPath()%>/login">
            <input type="hidden" name="oferta" value="<%=h(request.getParameter("oferta"))%>">
            <div class="field"><label for="correo">Correo electrónico</label><input class="form-control" id="correo" name="correo" type="email" autocomplete="username" placeholder="tu@correo.com" value="<%=h(request.getParameter("correo"))%>" required maxlength="150"></div>
            <div class="field"><label for="contrasena">Contraseña</label><div class="password-input"><input class="form-control" id="contrasena" name="contrasena" type="password" autocomplete="current-password" required><button class="icon-btn" type="button" data-toggle-password="contrasena" aria-label="Mostrar contraseña" title="Mostrar contraseña" aria-pressed="false"><i data-lucide="eye" aria-hidden="true"></i></button></div></div>
            <button class="btn primary" type="submit">Ingresar <i data-lucide="arrow-right" aria-hidden="true"></i></button>
        </form>
        <p class="login-security-note"><i data-lucide="shield-check" aria-hidden="true"></i><span>Por seguridad, la cuenta se bloquea durante 1 hora después de 3 intentos incorrectos.</span></p>
        <p class="auth-foot">¿Primera vez aquí? <a href="<%=request.getContextPath()%>/registro?oferta=<%=h(request.getParameter("oferta"))%>">Crea tu cuenta</a></p>
    </section>
</main><%@include file="WEB-INF/jspf/footer.jspf"%></body></html>
