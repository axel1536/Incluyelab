<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.incluyelab.model.Empresa"%>
<%@include file="jspf/helpers.jspf"%>
<% Empresa ficha=(Empresa)request.getAttribute("ficha"); %>
<!DOCTYPE html><html lang="es"><head><title><%=h(ficha.getRazonSocial())%> | IncluyeLab</title><%@include file="jspf/head.jspf"%></head><body>
<%@include file="jspf/header.jspf"%>
<main class="container dashboard admin-editor" id="contenido">
<a class="text-link" href="<%=request.getContextPath()%>/inicio#empresas"><i data-lucide="arrow-left" aria-hidden="true"></i> Volver al directorio</a>
<%@include file="jspf/empresa-detalle.jspf"%>
<p class="muted">Información declarada por la empresa. La aprobación del portal no constituye una certificación de accesibilidad ni acredita representación oficial de la marca.</p>
<div class="editor-actions"><a class="btn primary" href="<%=request.getContextPath()%>/inicio?empresa=<%=java.net.URLEncoder.encode(ficha.getRazonSocial(),"UTF-8")%>#ofertas"><i data-lucide="briefcase-business" aria-hidden="true"></i> Ver ofertas</a>
<% if(request.getAttribute("sitioOficial")!=null){ %><a class="btn" href="<%=h(request.getAttribute("sitioOficial"))%>" target="_blank" rel="noopener noreferrer">Sitio oficial <i data-lucide="external-link" aria-hidden="true"></i></a><% } %></div>
</main><%@include file="jspf/footer.jspf"%></body></html>
