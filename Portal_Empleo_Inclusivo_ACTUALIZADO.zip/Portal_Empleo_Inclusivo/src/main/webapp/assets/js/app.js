(() => {
    'use strict';
    const $ = (selector, root = document) => root.querySelector(selector);
    const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
    const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
    const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch (_) { return fallback; } };
    const write = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch (_) { return false; } };
    let toastTimer;
    function notify(message) {
        const toast = $('#toast');
        if (!toast) return;
        toast.textContent = message;
        toast.hidden = false;
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => { toast.hidden = true; }, 4500);
    }
    const preferences = read('incluyelab.preferences', {});
    const classes = { contrast: 'high-contrast', font: 'readable-font', large: 'large-text' };
    $$('[data-preference]').forEach(button => {
        const key = button.dataset.preference;
        const apply = () => {
            document.documentElement.classList.toggle(classes[key], !!preferences[key]);
            button.setAttribute('aria-pressed', String(!!preferences[key]));
        };
        apply();
        button.addEventListener('click', () => { preferences[key] = !preferences[key]; write('incluyelab.preferences', preferences); apply(); });
    });
    $('.menu-toggle')?.addEventListener('click', event => {
        const button = event.currentTarget;
        const open = $('#main-nav').classList.toggle('is-open');
        button.setAttribute('aria-expanded', String(open));
        button.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
    });
    $$('[data-toggle-password]').forEach(button => button.addEventListener('click', () => {
        const input = document.getElementById(button.dataset.togglePassword);
        const visible = input.type === 'password';
        input.type = visible ? 'text' : 'password';
        button.setAttribute('aria-pressed', String(visible));
        button.setAttribute('aria-label', visible ? 'Ocultar contraseña' : 'Mostrar contraseña');
        button.title = button.getAttribute('aria-label');
    }));
    $$('[data-password-rules]').forEach(list => {
        const input = document.getElementById(list.dataset.passwordRules);
        if (!input) return;
        const tests = {
            length: value => value.length >= 8 && value.length <= 100,
            upper: value => /[A-Z]/.test(value),
            lower: value => /[a-z]/.test(value),
            digit: value => /[0-9]/.test(value),
            special: value => /[^A-Za-z0-9\s]/.test(value),
            spaces: value => !/\s/.test(value)
        };
        const update = () => {
            const value = input.value;
            let valid = value.length > 0;
            $$('[data-rule]', list).forEach(item => {
                const met = tests[item.dataset.rule](value);
                item.classList.toggle('is-met', met);
                valid = valid && met;
            });
            input.setCustomValidity(value && !valid ? 'La contraseña todavía no cumple todos los requisitos.' : '');
        };
        input.addEventListener('input', update); update();
    });
    $$('[data-table-search]').forEach(input => input.addEventListener('input', () => {
        const table = document.getElementById(input.dataset.tableSearch);
        let count = 0;
        $$('tbody tr:not(.table-empty)', table).forEach(row => { row.hidden = !normalize(row.textContent).includes(normalize(input.value)); if (!row.hidden) count++; });
        let empty = $('.table-empty', table);
        if (!empty) { empty = document.createElement('tr'); empty.className = 'table-empty'; const cell = document.createElement('td'); cell.colSpan = $$('thead th', table).length; cell.textContent = 'No se encontraron resultados.'; empty.append(cell); $('tbody', table).append(empty); }
        empty.hidden = count > 0;
    }));
    const roleSelect = $('#rol');
    if (roleSelect && $('#nombre-label')) {
        const updateName = () => { $('#nombre-label').textContent = roleSelect.value === 'EMPRESA' ? 'Nombre de la empresa' : 'Nombre completo'; };
        updateName(); roleSelect.addEventListener('change', updateName);
    }
    window.lucide?.createIcons();
    const grid = $('#offer-grid');
    if (!grid) return;
    const cards = $$('.offer-card', grid);
    const stored = read('incluyelab.saved', []);
    const saved = new Set(Array.isArray(stored) ? stored.map(String) : []);
    let onlySaved = false;
    const aliases = name => normalize(name).replace('banco de credito del peru', 'bcp');
    function updateSaved() {
        $$('[data-save]').forEach(button => {
            const active = saved.has(button.dataset.save);
            button.setAttribute('aria-pressed', String(active));
            const title = button.closest('.offer-card').dataset.title;
            button.setAttribute('aria-label', (active ? 'Quitar de guardadas: ' : 'Guardar ') + title);
            button.title = active ? 'Quitar de guardadas' : 'Guardar oferta';
        });
        $('#saved-count').textContent = cards.filter(card => saved.has(card.dataset.id)).length;
    }
    function filter(sync = true) {
        const words = normalize($('#q').value).split(/\s+/).filter(Boolean);
        const location = normalize($('#ubicacion').value);
        const company = aliases($('#company-filter').value);
        const modes = $$('[name=modalidad]:checked').map(i => normalize(i.value));
        const needs = $$('[name=adaptacion]:checked').map(i => i.value);
        const order = $('#sort').value;
        cards.sort((a,b) => order === 'salary' ? Number(b.dataset.salary) - Number(a.dataset.salary) : order === 'title' ? a.dataset.title.localeCompare(b.dataset.title, 'es') : Number(b.dataset.id) - Number(a.dataset.id));
        let count = 0;
        cards.forEach(card => {
            const data = card.dataset;
            const haystack = normalize([data.title, aliases(data.company), data.location, data.adaptations, $('#detail-' + data.id)?.content.textContent].join(' '));
            const visible = words.every(word => haystack.includes(word)) && normalize(data.location).includes(location)
                && (!company || aliases(data.company).includes(company))
                && (!modes.length || modes.some(mode => normalize(data.mode).includes(mode)))
                && needs.every(need => (data.supports || '').split(',').includes(need))
                && (!onlySaved || saved.has(data.id));
            card.hidden = !visible;
            if (visible) count++;
            grid.append(card);
        });
        $('#result-count').textContent = count + (count === 1 ? ' empleo disponible' : ' empleos disponibles');
        $('#empty-results').hidden = count > 0;
        $('#saved-note').hidden = !onlySaved;
        if (sync) {
            const url = new URL(locationHref());
            ['q','ubicacion','empresa','modalidad','adaptacion','orden','guardadas'].forEach(key => url.searchParams.delete(key));
            [['q',$('#q').value.trim()],['ubicacion',$('#ubicacion').value.trim()],['empresa',$('#company-filter').value]].forEach(([key,value]) => { if (value) url.searchParams.set(key,value); });
            $$('[name=modalidad]:checked').forEach(i => url.searchParams.append('modalidad', i.value));
            needs.forEach(value => url.searchParams.append('adaptacion', value));
            if (order !== 'recent') url.searchParams.set('orden', order);
            if (onlySaved) url.searchParams.set('guardadas','1');
            history.replaceState({}, '', url);
        }
    }
    function locationHref() { return window.location.href; }
    function restoreFilters() {
        const params = new URL(locationHref()).searchParams;
        $('#q').value = params.get('q') || '';
        $('#ubicacion').value = params.get('ubicacion') || '';
        $('#company-filter').value = params.get('empresa') || '';
        $('#sort').value = ['recent','title','salary'].includes(params.get('orden')) ? params.get('orden') : 'recent';
        $$('[name=modalidad], [name=adaptacion]').forEach(input => { input.checked = params.getAll(input.name).map(normalize).includes(normalize(input.value)); });
        onlySaved = params.get('guardadas') === '1';
        $('.saved-filter').setAttribute('aria-pressed', String(onlySaved));
        filter(false);
    }
    function clearFilters() {
        $('#q').value = ''; $('#ubicacion').value = ''; $('#company-filter').value = ''; $('#sort').value = 'recent';
        $$('[name=modalidad], [name=adaptacion]').forEach(i => { i.checked = false; });
        onlySaved = false; $('.saved-filter').setAttribute('aria-pressed','false'); filter();
    }
    $('#clear-filters').addEventListener('click', clearFilters);
    $('#reset-results').addEventListener('click', clearFilters);
    $('#job-search').addEventListener('submit', event => { event.preventDefault(); filter(); $('#ofertas').scrollIntoView({block:'start'}); });
    $$('.filters input, .filters select, #sort').forEach(input => input.addEventListener('change', () => filter()));
    $('#q').addEventListener('search', () => filter());
    $('.saved-filter').addEventListener('click', () => { onlySaved = !onlySaved; $('.saved-filter').setAttribute('aria-pressed', String(onlySaved)); filter(); });
    $$('[data-save]').forEach(button => button.addEventListener('click', () => {
        const id = button.dataset.save;
        if (saved.has(id)) saved.delete(id); else saved.add(id);
        const persisted = write('incluyelab.saved', [...saved]);
        updateSaved(); filter();
        notify(persisted ? (saved.has(id) ? 'Oferta guardada en este navegador.' : 'Oferta eliminada de guardadas.') : 'Tu navegador no permite guardar esta preferencia. Se conservará mientras esta página esté abierta.');
    }));
    const dialog = $('#job-dialog');
    function openDetail(id, sync = true) {
        const template = document.getElementById('detail-' + id);
        if (!template) return;
        $('#dialog-content').replaceChildren(template.content.cloneNode(true));
        window.lucide?.createIcons();
        if (!dialog.open) dialog.showModal();
        if (sync) { const url = new URL(locationHref()); url.searchParams.set('oferta',id); history.replaceState({},'',url); }
    }
    $$('[data-detail]').forEach(button => button.addEventListener('click', event => { event.preventDefault(); openDetail(button.dataset.detail); }));
    $('[data-close-dialog]').addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', event => { if (event.target === dialog) { const r = dialog.getBoundingClientRect(); if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) dialog.close(); } });
    dialog.addEventListener('close', () => { const url = new URL(locationHref()); url.searchParams.delete('oferta'); history.replaceState({},'',url); });
    window.addEventListener('popstate', () => { restoreFilters(); const id = new URL(locationHref()).searchParams.get('oferta'); if (id) openDetail(id,false); else if (dialog.open) dialog.close(); });
    updateSaved(); restoreFilters();
    const initialOffer = new URL(locationHref()).searchParams.get('oferta');
    if (initialOffer) openDetail(initialOffer, false);
})();
