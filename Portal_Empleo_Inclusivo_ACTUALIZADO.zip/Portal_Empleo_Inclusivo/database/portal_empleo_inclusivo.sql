CREATE DATABASE IF NOT EXISTS portal_empleo_inclusivo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'incluyelab_app'@'localhost' IDENTIFIED BY '123456';
GRANT ALL PRIVILEGES ON portal_empleo_inclusivo.* TO 'incluyelab_app'@'localhost';
FLUSH PRIVILEGES;
USE portal_empleo_inclusivo;

CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    correo VARCHAR(150) NOT NULL UNIQUE,
    contrasena VARCHAR(100) NOT NULL,
    rol ENUM('ADMIN', 'POSTULANTE', 'EMPRESA') NOT NULL,
    estado ENUM('activo', 'inactivo') NOT NULL DEFAULT 'activo',
    intentos_fallidos TINYINT UNSIGNED NOT NULL DEFAULT 0,
    bloqueado_hasta DATETIME NULL,
    fecha_registro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

SET @sql=IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='usuarios' AND column_name='intentos_fallidos')=0, 'ALTER TABLE usuarios ADD COLUMN intentos_fallidos TINYINT UNSIGNED NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE seguridad_stmt FROM @sql; EXECUTE seguridad_stmt; DEALLOCATE PREPARE seguridad_stmt;
SET @sql=IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='usuarios' AND column_name='bloqueado_hasta')=0, 'ALTER TABLE usuarios ADD COLUMN bloqueado_hasta DATETIME NULL', 'SELECT 1');
PREPARE seguridad_stmt FROM @sql; EXECUTE seguridad_stmt; DEALLOCATE PREPARE seguridad_stmt;

CREATE TABLE IF NOT EXISTS empresas (
    id_empresa INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    razon_social VARCHAR(150) NOT NULL,
    ruc VARCHAR(11) NOT NULL,
    sector VARCHAR(100) NOT NULL,
    logo_url VARCHAR(255),
    sello_inclusivo ENUM('Certificado', 'En revision', 'Pendiente') NOT NULL DEFAULT 'Pendiente',
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
);

SET @logo_col_exists := (
    SELECT COUNT(*)
    FROM information_schema.columns
    WHERE table_schema = 'portal_empleo_inclusivo'
      AND table_name = 'empresas'
      AND column_name = 'logo_url'
);
SET @logo_col_sql := IF(@logo_col_exists = 0, 'ALTER TABLE empresas ADD COLUMN logo_url VARCHAR(255)', 'SELECT 1');
PREPARE logo_col_stmt FROM @logo_col_sql;
EXECUTE logo_col_stmt;
DEALLOCATE PREPARE logo_col_stmt;

CREATE TABLE IF NOT EXISTS perfiles_postulantes (
    id_perfil INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    dni VARCHAR(8),
    telefono VARCHAR(20),
    habilidades VARCHAR(255),
    tipo_discapacidad VARCHAR(120),
    adaptacion_requerida VARCHAR(255),
    experiencia TEXT,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
);

CREATE TABLE IF NOT EXISTS ofertas (
    id_oferta INT AUTO_INCREMENT PRIMARY KEY,
    id_empresa INT NOT NULL,
    titulo VARCHAR(150) NOT NULL,
    modalidad VARCHAR(80) NOT NULL,
    ubicacion VARCHAR(120) NOT NULL,
    adaptaciones VARCHAR(255) NOT NULL,
    descripcion TEXT NOT NULL,
    salario DECIMAL(10,2) NOT NULL DEFAULT 0,
    estado ENUM('activa', 'cerrada') NOT NULL DEFAULT 'activa',
    fecha_publicacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_empresa) REFERENCES empresas(id_empresa)
);

CREATE TABLE IF NOT EXISTS postulaciones (
    id_postulacion INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_oferta INT NOT NULL,
    estado ENUM('pendiente', 'en revision', 'aceptado', 'rechazado') NOT NULL DEFAULT 'pendiente',
    fecha_postulacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario),
    FOREIGN KEY (id_oferta) REFERENCES ofertas(id_oferta)
);

INSERT IGNORE INTO usuarios(id_usuario, nombre, correo, contrasena, rol) VALUES
(1, 'Administrador Principal', 'admin@incluyelab.pe', '123456', 'ADMIN'),
(2, 'Microsoft (cuenta demo)', 'empresa@incluyelab.pe', '123456', 'EMPRESA'),
(3, 'Sofia Ramirez', 'sofia@correo.com', '123456', 'POSTULANTE'),
(4, 'Luis Torres', 'luis@correo.com', '123456', 'POSTULANTE'),
(5, 'Banco de Credito del Peru', 'talento@bcp.com.pe', '123456', 'EMPRESA'),
(6, 'Interbank', 'empleos@interbank.pe', '123456', 'EMPRESA'),
(7, 'Alicorp', 'personas@alicorp.com.pe', '123456', 'EMPRESA'),
(8, 'Rimac Seguros', 'inclusion@rimac.com', '123456', 'EMPRESA'),
(9, 'Entel Peru', 'talento@entel.pe', '123456', 'EMPRESA'),
(10, 'Sodimac Peru', 'empleos@sodimac.com.pe', '123456', 'EMPRESA'),
(11, 'Inkafarma', 'trabaja@inkafarma.pe', '123456', 'EMPRESA'),
(12, 'Yape', 'talento@yape.com.pe', '123456', 'EMPRESA');

INSERT IGNORE INTO empresas(id_empresa, id_usuario, razon_social, ruc, sector, logo_url, sello_inclusivo) VALUES
(1, 2, 'Microsoft', '00000000000', 'Tecnologia', 'assets/logos/microsoft.png', 'Pendiente'),
(2, 5, 'BCP', '20100047218', 'Banca', 'https://logo.clearbit.com/bcp.com.pe', 'Certificado'),
(3, 6, 'Interbank', '20100053455', 'Banca', 'https://logo.clearbit.com/interbank.pe', 'Certificado'),
(4, 7, 'Alicorp', '20100055237', 'Consumo masivo', 'https://logo.clearbit.com/alicorp.com.pe', 'En revision'),
(5, 8, 'Rimac Seguros', '20100041953', 'Seguros', 'https://logo.clearbit.com/rimac.com', 'Certificado'),
(6, 9, 'Entel Peru', '20543254798', 'Telecomunicaciones', 'https://logo.clearbit.com/entel.pe', 'En revision'),
(7, 10, 'Sodimac Peru', '20389230724', 'Retail', 'https://logo.clearbit.com/sodimac.com.pe', 'Certificado'),
(8, 11, 'Inkafarma', '20100028698', 'Salud y retail', 'https://logo.clearbit.com/inkafarma.pe', 'Certificado'),
(9, 12, 'Yape', '20538888029', 'Fintech', 'https://logo.clearbit.com/yape.com.pe', 'Certificado');

UPDATE empresas SET logo_url='https://logo.clearbit.com/bcp.com.pe' WHERE razon_social='BCP' AND (logo_url IS NULL OR logo_url='');
UPDATE empresas SET logo_url='https://logo.clearbit.com/interbank.pe' WHERE razon_social='Interbank' AND (logo_url IS NULL OR logo_url='');
UPDATE empresas SET logo_url='https://logo.clearbit.com/alicorp.com.pe' WHERE razon_social='Alicorp' AND (logo_url IS NULL OR logo_url='');
UPDATE empresas SET logo_url='https://logo.clearbit.com/rimac.com' WHERE razon_social='Rimac Seguros' AND (logo_url IS NULL OR logo_url='');

INSERT IGNORE INTO perfiles_postulantes(id_perfil, id_usuario, dni, telefono, habilidades, tipo_discapacidad, adaptacion_requerida, experiencia) VALUES
(1, 3, '70112233', '999111222', 'Atencion al cliente, Excel, soporte remoto', 'Movilidad reducida', 'Acceso con rampa y horario flexible', 'Experiencia en soporte administrativo.'),
(2, 4, '71223344', '988777666', 'Diseno grafico, redes sociales, redaccion', 'Visual leve', 'Compatibilidad con lector de pantalla', 'Practicas en comunicacion digital.');

INSERT IGNORE INTO ofertas(id_oferta, id_empresa, titulo, modalidad, ubicacion, adaptaciones, descripcion, salario) VALUES
(1, 1, 'Asistente de soporte remoto', 'Remoto', 'Lima', 'Horario flexible, lector de pantalla, reuniones grabadas', 'Atencion de tickets y orientacion a usuarios desde casa.', 1800.00),
(2, 1, 'Auxiliar administrativo inclusivo', 'Presencial accesible', 'San Juan de Lurigancho', 'Rampa, ascensor, escritorio ergonomico', 'Apoyo en registro documental, control de archivos y atencion interna.', 1500.00),
(3, 1, 'Analista junior de datos', 'Hibrido', 'Lima Centro', 'Capacitacion inicial, mentor asignado, herramientas accesibles', 'Limpieza de datos, reportes basicos y seguimiento de indicadores.', 2200.00),
(4, 2, 'Asistente de experiencia al cliente inclusivo', 'Hibrido', 'Lima, Peru', 'Lector de pantalla, horario flexible, reuniones con subtitulos', 'Atender consultas digitales y orientar a clientes desde canales accesibles.', 2400.00),
(5, 3, 'Practicante de tecnologia accesible', 'Hibrido', 'San Isidro, Lima', 'Mentor asignado, laptop adaptada, espacios sin barreras', 'Apoyo en pruebas de accesibilidad digital y documentacion de incidencias.', 1800.00),
(6, 4, 'Analista de datos junior', 'Remoto', 'Peru', 'Trabajo remoto, comunicacion escrita, pausas sensoriales', 'Crear reportes operativos y tableros basicos para areas comerciales.', 2600.00),
(7, 5, 'Ejecutivo de soporte administrativo', 'Presencial accesible', 'Miraflores, Lima', 'Ascensor, rutas accesibles, interprete LS previa coordinacion', 'Gestion documental y atencion interna para equipos de seguros.', 2300.00),
(8, 6, 'Asesor de atencion digital', 'Remoto', 'Lima y provincias', 'Software lector, capacitacion inclusiva, horario flexible', 'Atender usuarios por canales digitales y resolver requerimientos frecuentes.', 1900.00),
(9, 7, 'Auxiliar de tienda con accesibilidad', 'Presencial accesible', 'Ate, Lima', 'Rampas, senalizacion clara, acompanamiento inicial', 'Apoyo en orden, reposicion ligera y orientacion al cliente.', 1600.00),
(10, 8, 'Asistente de operaciones farmaceuticas', 'Hibrido', 'Lima Norte', 'Entorno guiado, capacitacion por pasos, comunicacion visual', 'Registrar informacion operativa y dar soporte a equipos de farmacia.', 1700.00),
(11, 9, 'Analista junior de producto digital', 'Hibrido', 'La Molina, Lima', 'Subtitulos, lector de pantalla, reuniones grabadas', 'Apoyar en seguimiento de funcionalidades, indicadores y pruebas de usuario.', 2800.00);

INSERT IGNORE INTO postulaciones(id_postulacion, id_usuario, id_oferta, estado) VALUES
(1, 3, 1, 'pendiente'),
(2, 4, 3, 'en revision');

-- Non-destructive migration: explicit support declarations for phase 1.
USE portal_empleo_inclusivo;
SET @existe_apoyos = (SELECT COUNT(*) FROM information_schema.columns
    WHERE table_schema=DATABASE() AND table_name='ofertas' AND column_name='apoyos');
SET @sql_apoyos = IF(@existe_apoyos=0,
    'ALTER TABLE ofertas ADD COLUMN apoyos VARCHAR(512) NOT NULL DEFAULT ''''',
    'SELECT 1');
PREPARE stmt_apoyos FROM @sql_apoyos;
EXECUTE stmt_apoyos;
DEALLOCATE PREPARE stmt_apoyos;

-- Only annotate the original demonstration text, not arbitrary offers.
-- Exact matches avoid inventing support for user-authored or edited content.
UPDATE ofertas SET apoyos=CASE adaptaciones
    WHEN 'Horario flexible, lector de pantalla, reuniones grabadas' THEN 'lector,flexible'
    WHEN 'Rampa, ascensor, escritorio ergonomico' THEN 'rampas,ascensores'
    WHEN 'Lector de pantalla, horario flexible, reuniones con subtitulos' THEN 'lector,subtitulos,flexible'
    WHEN 'Trabajo remoto, comunicacion escrita, pausas sensoriales' THEN 'escrita'
    WHEN 'Ascensor, rutas accesibles, interprete LS previa coordinacion' THEN 'ascensores'
    WHEN 'Software lector, capacitacion inclusiva, horario flexible' THEN 'lector,flexible'
    WHEN 'Rampas, senalizacion clara, acompanamiento inicial' THEN 'rampas'
    WHEN 'Subtitulos, lector de pantalla, reuniones grabadas' THEN 'lector,subtitulos'
    ELSE apoyos END
WHERE apoyos='' AND @existe_apoyos=0;

-- Non-destructive and repeatable. Existing demo records retain visibility.
USE portal_empleo_inclusivo;
SET @missing=(SELECT COUNT(*)=0 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='empresas' AND column_name='estado_revision');
SET @ddl=IF(@missing, 'ALTER TABLE empresas ADD COLUMN estado_revision ENUM(''pendiente'',''aprobada'',''rechazada'') NOT NULL DEFAULT ''pendiente''', 'SELECT 1');
PREPARE migration FROM @ddl;
EXECUTE migration;
DEALLOCATE PREPARE migration;

-- Perfil profesional y seguimiento de postulaciones (2026-10-18).
SET @sql = IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='perfiles_postulantes' AND column_name='titular')=0,
 'ALTER TABLE perfiles_postulantes ADD COLUMN titular VARCHAR(160) NOT NULL DEFAULT '''', ADD COLUMN ubicacion VARCHAR(120) NOT NULL DEFAULT '''', ADD COLUMN acerca_de TEXT NULL, ADD COLUMN foto_url VARCHAR(255) NOT NULL DEFAULT '''', ADD COLUMN cv_nombre VARCHAR(255) NOT NULL DEFAULT '''', ADD COLUMN cv_archivo VARCHAR(255) NOT NULL DEFAULT '''', ADD COLUMN cv_actualizado DATETIME NULL', 'SELECT 1');
PREPARE perfil_stmt FROM @sql; EXECUTE perfil_stmt; DEALLOCATE PREPARE perfil_stmt;
SET @sql = IF((SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='perfiles_postulantes' AND index_name='uq_perfil_usuario')=0, 'ALTER TABLE perfiles_postulantes ADD UNIQUE KEY uq_perfil_usuario(id_usuario)', 'SELECT 1');
PREPARE perfil_stmt FROM @sql; EXECUTE perfil_stmt; DEALLOCATE PREPARE perfil_stmt;
CREATE TABLE IF NOT EXISTS experiencias_postulante (id_experiencia INT AUTO_INCREMENT PRIMARY KEY,id_usuario INT NOT NULL,cargo VARCHAR(150) NOT NULL,organizacion VARCHAR(150) NOT NULL,fecha_inicio VARCHAR(30) NOT NULL,fecha_fin VARCHAR(30) NOT NULL,descripcion VARCHAR(2000) NOT NULL DEFAULT '',FOREIGN KEY(id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS educacion_postulante (id_educacion INT AUTO_INCREMENT PRIMARY KEY,id_usuario INT NOT NULL,institucion VARCHAR(180) NOT NULL,carrera VARCHAR(180) NOT NULL,fecha_inicio VARCHAR(30) NOT NULL,fecha_fin VARCHAR(30) NOT NULL,descripcion VARCHAR(2000) NOT NULL DEFAULT '',FOREIGN KEY(id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS certificaciones_postulante (id_certificacion INT AUTO_INCREMENT PRIMARY KEY,id_usuario INT NOT NULL,nombre VARCHAR(200) NOT NULL,emisor VARCHAR(150) NOT NULL,fecha_emision VARCHAR(30) NOT NULL,credencial_url VARCHAR(500) NOT NULL DEFAULT '',FOREIGN KEY(id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE);
SET @sofia=(SELECT id_usuario FROM usuarios WHERE correo='sofia@correo.com' AND rol='POSTULANTE' LIMIT 1);
INSERT INTO perfiles_postulantes(id_usuario,telefono,habilidades,adaptacion_requerida,titular,ubicacion,acerca_de,foto_url) SELECT @sofia,'999111222','Java, MySQL, HTML, CSS, Bootstrap, soporte TI, trabajo en equipo','Indicaciones escritas, herramientas compatibles con lector de pantalla y modalidad híbrida','Estudiante de Ingeniería de Sistemas | Java, MySQL y soporte TI','San Juan de Lurigancho, Lima','Perfil de demostración. Estudiante de Ingeniería de Sistemas interesada en desarrollo web, bases de datos y soporte tecnológico. Me motiva crear soluciones digitales accesibles, documentar procesos con claridad y colaborar en equipos diversos. Busco una oportunidad preprofesional para seguir aprendiendo y aportar con responsabilidad.','asset:perfil-sofia-demo.png' WHERE @sofia IS NOT NULL ON DUPLICATE KEY UPDATE telefono=VALUES(telefono),habilidades=VALUES(habilidades),adaptacion_requerida=VALUES(adaptacion_requerida),titular=VALUES(titular),ubicacion=VALUES(ubicacion),acerca_de=VALUES(acerca_de),foto_url=VALUES(foto_url);
INSERT INTO experiencias_postulante(id_usuario,cargo,organizacion,fecha_inicio,fecha_fin,descripcion) SELECT @sofia,'Practicante de soporte y desarrollo web','Proyecto académico IncluyeLab','Abr. 2025','Dic. 2025','Experiencia ficticia de demostración: apoyo en pruebas funcionales, documentación de incidencias y construcción de interfaces accesibles con Java, JSP, Bootstrap y MySQL.' WHERE @sofia IS NOT NULL AND NOT EXISTS(SELECT 1 FROM experiencias_postulante WHERE id_usuario=@sofia AND organizacion='Proyecto académico IncluyeLab');
INSERT INTO educacion_postulante(id_usuario,institucion,carrera,fecha_inicio,fecha_fin,descripcion) SELECT @sofia,'Universidad Privada del Norte','Ingeniería de Sistemas Computacionales','Mar. 2023','Actualidad','Formación ficticia de demostración enfocada en programación, bases de datos, análisis de sistemas y desarrollo de aplicaciones web.' WHERE @sofia IS NOT NULL AND NOT EXISTS(SELECT 1 FROM educacion_postulante WHERE id_usuario=@sofia AND institucion='Universidad Privada del Norte');
INSERT INTO certificaciones_postulante(id_usuario,nombre,emisor,fecha_emision,credencial_url) SELECT @sofia,'Fundamentos de bases de datos','Programa académico de demostración','Ago. 2026','' WHERE @sofia IS NOT NULL AND NOT EXISTS(SELECT 1 FROM certificaciones_postulante WHERE id_usuario=@sofia AND nombre='Fundamentos de bases de datos');
INSERT INTO certificaciones_postulante(id_usuario,nombre,emisor,fecha_emision,credencial_url) SELECT @sofia,'Introducción a la accesibilidad web','IncluyeLab - contenido demostrativo','Sep. 2026','' WHERE @sofia IS NOT NULL AND NOT EXISTS(SELECT 1 FROM certificaciones_postulante WHERE id_usuario=@sofia AND nombre='Introducción a la accesibilidad web');
UPDATE empresas SET estado_revision='aprobada' WHERE @missing=1;
SET @missing=(SELECT COUNT(*)=0 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='empresas' AND column_name='presentacion');
SET @ddl=IF(@missing, 'ALTER TABLE empresas ADD COLUMN presentacion TEXT NULL', 'SELECT 1');
PREPARE migration FROM @ddl;
EXECUTE migration;
DEALLOCATE PREPARE migration;
SET @missing=(SELECT COUNT(*)=0 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='empresas' AND column_name='anio_inicio');
SET @ddl=IF(@missing, 'ALTER TABLE empresas ADD COLUMN anio_inicio INT NULL', 'SELECT 1');
PREPARE migration FROM @ddl;
EXECUTE migration;
DEALLOCATE PREPARE migration;
SET @missing=(SELECT COUNT(*)=0 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='empresas' AND column_name='logros');
SET @ddl=IF(@missing, 'ALTER TABLE empresas ADD COLUMN logros TEXT NULL', 'SELECT 1');
PREPARE migration FROM @ddl;
EXECUTE migration;
DEALLOCATE PREPARE migration;
SET @missing=(SELECT COUNT(*)=0 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='empresas' AND column_name='motivo_revision');
SET @ddl=IF(@missing, 'ALTER TABLE empresas ADD COLUMN motivo_revision VARCHAR(1000) NOT NULL DEFAULT ''''', 'SELECT 1');
PREPARE migration FROM @ddl;
EXECUTE migration;
DEALLOCATE PREPARE migration;
SET @missing=(SELECT COUNT(*)=0 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='empresas' AND column_name='version_revision');
SET @ddl=IF(@missing, 'ALTER TABLE empresas ADD COLUMN version_revision INT NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE migration FROM @ddl;
EXECUTE migration;
DEALLOCATE PREPARE migration;
SET @missing=(SELECT COUNT(*)=0 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='empresas' AND column_name='fecha_revision');
SET @ddl=IF(@missing, 'ALTER TABLE empresas ADD COLUMN fecha_revision DATETIME NULL', 'SELECT 1');
PREPARE migration FROM @ddl;
EXECUTE migration;
DEALLOCATE PREPARE migration;
SET @missing=(SELECT COUNT(*)=0 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='empresas' AND column_name='revisor_id');
SET @ddl=IF(@missing, 'ALTER TABLE empresas ADD COLUMN revisor_id INT NULL', 'SELECT 1');
PREPARE migration FROM @ddl;
EXECUTE migration;
DEALLOCATE PREPARE migration;

