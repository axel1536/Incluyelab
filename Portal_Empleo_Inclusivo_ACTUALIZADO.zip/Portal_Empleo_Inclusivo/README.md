# Portal de Empleo Inclusivo

Proyecto web Java desarrollado para NetBeans con JSP, Servlets, JavaBeans, DAO y MySQL.

## Tema

Portal Web de Empleo Inclusivo para la reduccion de desigualdades laborales, alineado al ODS 10.

## Roles

- Administrador: crea, consulta, busca, edita y elimina usuarios, empresas, ofertas y postulaciones.
- Postulante: revisa ofertas inclusivas y registra postulaciones.
- Empresa: publica ofertas laborales accesibles.

## Usuarios de prueba

Todos usan la clave `123456`.

- `admin@incluyelab.pe`
- `empresa@incluyelab.pe`
- `sofia@correo.com`

## Base de datos

Ejecutar en MySQL Workbench:

```sql
source database/portal_empleo_inclusivo.sql;
```

O abrir el archivo `database/portal_empleo_inclusivo.sql` y ejecutar todo el script.

La conexion por defecto usa:

- Base de datos: `portal_empleo_inclusivo`
- Configura `DB_USER` y `DB_PASSWORD` con las credenciales de tu MySQL local antes de iniciar Tomcat.
- El script crea el usuario local de desarrollo `incluyelab_app`.

Tambien se puede configurar con variables de entorno:

- `DB_URL`
- `DB_USER`
- `DB_PASSWORD`

## Abrir en NetBeans

1. Abrir Apache NetBeans.
2. Ir a `File > Open Project`.
3. Seleccionar la carpeta `Portal_Empleo_Inclusivo`.
4. Ejecutar `Clean and Build`.
5. Correr el proyecto con Apache Tomcat 9.

## Rutas principales

- `/inicio`: pagina publica con ofertas.
- `/login`: inicio de sesion.
- `/registro`: registro de usuarios.
- `/postulante`: panel del postulante.
- `/empresa`: panel de empresa.
- `/admin`: panel administrador.

## Interfaz actualizada

La portada mantiene la carga de ofertas desde MySQL y agrega busqueda por texto y ubicacion,
filtros por modalidad, empresa y adaptaciones, orden por salario/titulo, y detalle de cada oferta.
Los formularios de registro, ingreso, publicacion y postulacion usan los Servlets y DAO existentes.

- Preferencias de contraste, fuente legible y texto ampliado: guardadas en el navegador.
- Ofertas guardadas: solo en ese navegador, no en la cuenta MySQL.
- Cuentas, ofertas publicadas y postulaciones: persistentes en MySQL.
- Los 23 logos, las fuentes y los iconos se sirven desde `src/main/webapp/assets`.
- El directorio incluye empresas sin ofertas; seleccionarlas muestra el estado sin resultados.
- Las vacantes de demostracion no son convocatorias oficiales de las marcas mostradas.

Archivos de presentacion: `src/main/webapp/*.jsp`, `WEB-INF/jspf`, `assets/css/styles.css`
y `assets/js/app.js`. Los includes compartidos conservan UTF-8 para los textos en espanol.

## Verificacion

`tools/verify-portal.cjs` prueba con Playwright la busqueda, filtros, guardadas, detalle,
accesibilidad y vistas de 390, 768 y 1440 px. Con `PORTAL_DB_PASSWORD`, tambien crea
cuentas temporales de empresa y postulante, publica una oferta, registra una postulacion,
verifica sus filas en MySQL y elimina exclusivamente los datos creados por esa ejecucion.
Necesita Microsoft Edge, Playwright (`PLAYWRIGHT_MODULE`) y MySQL CLI (`MYSQL_EXE`).
El ingreso administrativo de prueba puede configurarse con `PORTAL_ADMIN_PASSWORD`.
Los resultados y capturas quedan en `verification/`.

## Bootstrap y CRUD administrativo

Bootstrap 5.3.8 esta integrado localmente en `assets/vendor`, sin depender de un CDN
para navegar. `WEB-INF/jspf/head.jspf` lo carga antes del tema del portal.
Los formularios utilizan `form-control` y `form-select`; las pantallas de empresa y
administracion usan la grilla `row`, `col-md-6` y `col-12`. Las tablas utilizan
`table-responsive`, `table-hover` y `align-middle`; los avisos administrativos
usan el componente Alert de Bootstrap con cierre interactivo.

- Usuarios: crear cuenta, editar datos/rol/estado y eliminar cuando no tiene dependencias.
  Una contrasena vacia al editar conserva la actual. No se puede eliminar ni desactivar
  la propia cuenta administrativa. Los roles con perfiles vinculados se conservan.
- Empresas: registro propio y aprobacion/rechazo administrativo. Ya no hay alta
  de empresas desde el administrador; sus responsables completan la ficha.
- Ofertas: crear para una empresa aprobada y activa, editar contenido/salario/estado y eliminar
  si no existen postulaciones. Una oferta cerrada deja de aparecer en el portal publico.
- Postulaciones: crear para un postulante activo y oferta activa, cambiar su estado y
  eliminar. Al editar se conserva el postulante y la oferta originales.
- Todas las escrituras requieren POST, sesion de administrador activo y token CSRF.
  El servidor valida los datos y las claves foraneas protegen el historial relacionado.
  Abrir la confirmacion o pulsar Cancelar no elimina informacion.

Implementacion: `AdminServlet.java`, `AdminDAO.java`, `admin.jsp`,
`WEB-INF/admin-form.jsp` y `WEB-INF/admin-delete.jsp`.
Se mantiene la arquitectura JSP, Servlets, JavaBeans, DAO y MySQL.
No se requiere ejecutar de nuevo el script de creacion de la base existente.

`tools/verify-admin.cjs` corresponde al flujo anterior de cuatro CRUD mediante el navegador
y SELECT en MySQL, validaciones, permisos, CSRF, cancelacion y dependencias.
Tambien captura el panel y formularios a 390, 768 y 1440 px y en alto contraste.
Usa las mismas variables que `verify-portal.cjs`; requiere `PORTAL_DB_PASSWORD`.
Las pruebas limpian exclusivamente sus propios registros temporales.
Resultados: `verification/admin-results.json`.

## Sesiones y filtros (15 de octubre de 2026)

El control comun en `SesionFilter` protege paneles y JSP por rol, revalida
cuentas activas y revoca sesiones ante cambios de rol/estado. El login renueva
la sesion; el timeout es de 30 minutos. Las respuestas dinamicas no se almacenan
en cache y la cookie de sesion es HttpOnly.

Las adaptaciones se seleccionan explicitamente al crear/editar ofertas y se
guardan en `ofertas.apoyos`. La busqueda ya no infiere apoyos por palabras del
titulo o la descripcion. La fase 1 comprende fisica, visual y auditiva;
horario flexible/pausas son complementos y Remoto es una modalidad.
Las fases 2 y 3 siguen pendientes.

Para actualizar una instalacion ANTERIOR ejecutar solamente
`database/migrations/20261015_apoyos_ofertas.sql` antes de desplegar el WAR nuevo.
La base local de esta entrega ya fue migrada. No reimportar datos demo para actualizar.
Para una base NUEVA, `database/portal_empleo_inclusivo.sql` incluye la migracion.

Evidencia tecnica y recorrido por archivos: `docs/VERIFICACION_RUBRICA.md`.
Prueba adicional: `tools/verify-sessions-supports.cjs`, con las mismas variables
de entorno de las otras pruebas. Resultados en `verification/sessions-supports-results.json`.

## Recursos visuales

El directorio incluye 23 marcas reales: empresas con presencia en Peru y referencias
internacionales identificadas como tales. Se incorporaron Microsoft, Amazon, Walmart,
Mercado Libre, Falabella, SAP, ACCIONA, Clinica Internacional, Clinica San Pablo Surco
y Pardos Chicken. Cada ficha enlaza al sitio oficial y al filtro de ofertas del portal.
No se inventan convocatorias ni cuentas de acceso para estas marcas.
La cuenta de empresa demo original conserva su correo y clave, y ahora usa Microsoft
como marca de referencia (no es una cuenta real de esa empresa). Las ofertas del
prototipo se identifican como demostrativas.

Catalogo: `src/main/java/com/incluyelab/model/DirectorioEmpresas.java`.
Los diez logos nuevos provienen de sitios oficiales; sus URLs estan en sources.json.
`tools/download-company-logos.cjs` permite descargarlos de nuevo.
Migracion de la empresa ficticia original: `database/migrations/20261015_empresa_demo_real.sql`.

- Referencia de experiencia: Evenbreak, https://www.evenbreak.co.uk/
- Logos: sitios oficiales de las empresas y archivos de Wikimedia Commons.
  Las direcciones originales estan en `src/main/webapp/assets/logos/sources.json`.
- Iconos: Lucide 0.468.0 (ISC). Fuentes: Ubuntu y Atkinson Hyperlegible, via Google Fonts.
- Bootstrap 5.3.8 (MIT): https://getbootstrap.com/docs/5.3/getting-started/introduction/
- `tools/download-assets.cjs` permite volver a descargar los recursos; no se ejecuta al navegar.

## Cambiar la contrasena desde Mi perfil

Administrador, Empresa y Postulante tienen el enlace **Mi perfil** en el menu.
Desde `/perfil` ingresan la clave actual, una nueva de 8 a 100 caracteres y su
confirmacion. El cambio se guarda en MySQL; luego deben iniciar sesion nuevamente.
Las otras sesiones de la misma cuenta se revocan en su siguiente solicitud.

Las nuevas claves se almacenan con PBKDF2-HMAC-SHA256 y sal aleatoria, tanto desde
perfil como desde registro y administracion. Las cuentas anteriores siguen
funcionando con su clave actual hasta que la cambien. No hay migracion de tablas.

Prueba automatizada: `tools/verify-password.cjs` (requiere `PLAYWRIGHT_MODULE` y
`PORTAL_DB_PASSWORD`). Usa cuentas temporales que elimina al terminar, sin crear
empresas ni ofertas. Evidencia: `verification/password-results.json` y capturas
`verification/perfil-*.png`.
## Solicitudes de empresas y ficha publica

1. La empresa crea su cuenta en Registro, con rol Empresa.
2. En Mi panel abre Editar presentacion y completa su ficha.
3. El administrador abre Solicitudes de empresas > Revisar solicitud.
4. Aprueba o rechaza indicando observaciones. La empresa consulta el resultado en su panel.
5. Al aprobarse puede publicar ofertas. Editar la ficha exige nueva revision y oculta
   sus ofertas mientras esta pendiente, sin borrarlas.

El perfil publico muestra presentacion, sector, ano de inicio, trayectoria calculada
por ano y logros/metas cumplidas. Los campos antiguos sin informacion no se inventan.
Los logos existentes se mantienen. Las marcas del directorio tambien tienen enlace
a su ficha de referencia; no implica que esten registradas ni tengan convenios.

Migracion para una base existente:
`database/migrations/20261016_revision_empresas.sql` (aplicada en este equipo).
El instalador SQL completo incluye esta migracion. No volver a importar toda la base
para actualizar una instalacion existente. Las empresas previas se conservan visibles
como aprobadas importadas; las nuevas quedan pendientes. Reaplicar no altera revisiones.

Comprobacion de solo lectura: `tools/verify-company-review.cjs`.
Resultados: `verification/company-review-results.json`.
Por indicacion del usuario, NO se crearon empresas/ofertas ni se ejecutaron pruebas
de escritura de este flujo. Compilacion, pantallas y permisos GET comprobados.

